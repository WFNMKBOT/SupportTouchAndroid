package com.supporttouch.android;

import android.os.Build;
import android.content.pm.PackageManager;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.media.AudioManager;

public class MainActivity extends Activity {

    LinearLayout main;
    AudioManager audio;

    int blue = Color.rgb(45, 112, 240);
    int dark = Color.rgb(22, 32, 51);
    int gray = Color.rgb(110, 120, 135);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        audio = (AudioManager)
            getSystemService(AUDIO_SERVICE);

        getWindow().setStatusBarColor(dark);
        getWindow().setNavigationBarColor(dark);

        ScrollView scroll = new ScrollView(this);

        main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(22, 28, 22, 28);
        main.setBackgroundColor(Color.rgb(244, 247, 252));

        scroll.addView(main);

        createHeader();
        createFloatingCard();
        createQuickActions();
        createDeviceControls();
        createThemeSection();

        setContentView(scroll);
    }

    void createHeader() {
        main.addView(text(
            "Support Touch", 28, dark, true
        ));

        main.addView(text(
            "Modern Android Control Center",
            14, gray, false
        ));

        space(25);
    }

    void createFloatingCard() {
        LinearLayout card = card();

        card.addView(text(
            "FLOATING TOUCH", 13, blue, true
        ));

        card.addView(text(
            "Your assistant is ready",
            21, dark, true
        ));

        card.addView(text(
            "Aktifkan tombol melayang di layar HP.",
            13, gray, false
        ));

        TextView start = button(
            "AKTIFKAN FLOATING TOUCH"
        );

        card.addView(start);

        start.setOnClickListener(v -> {

    if (Settings.canDrawOverlays(this)) {

        requestNotificationPermission();

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(
                new Intent(this, FloatingService.class)
            );
        } else {
            startService(
                new Intent(this, FloatingService.class)
            );
        }

        Toast.makeText(
            this,
            "Floating Touch diaktifkan",
            Toast.LENGTH_SHORT
        ).show();

    } else {

        Intent intent = new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())
        );

        startActivity(intent);
    }
});

        TextView stop = button(
            "MATIKAN FLOATING TOUCH"
        );

        stop.setBackground(background(
            Color.rgb(210, 65, 65), 14
        ));

        card.addView(stop);

        stop.setOnClickListener(v -> {
            stopService(
                new Intent(this, FloatingService.class)
            );

            Toast.makeText(
                this,
                "Floating Touch dimatikan",
                Toast.LENGTH_SHORT
            ).show();
        });

        TextView accessibility = button(
            "AKTIFKAN IZIN KONTROL"
        );

        accessibility.setBackground(
            background(Color.rgb(35, 150, 110), 14)
        );

        card.addView(accessibility);

        accessibility.setOnClickListener(v -> {
            startActivity(new Intent(
                Settings.ACTION_ACCESSIBILITY_SETTINGS
            ));
        });

        main.addView(card);
        space(24);
    }

    void createQuickActions() {
        heading("Quick Actions");

        addAction("⌂", "Home",
            "Kembali ke layar utama", () -> {
                runAccessibilityAction(
                    TouchAccessibilityService.ACTION_HOME
                );
            });

        addAction("‹", "Back",
            "Kembali ke halaman sebelumnya", () -> {
                runAccessibilityAction(
                    TouchAccessibilityService.ACTION_BACK
                );
            });

        addAction("▣", "Recent Apps",
            "Melihat aplikasi terbaru", () -> {
                runAccessibilityAction(
                    TouchAccessibilityService.ACTION_RECENTS
                );
            });

        addAction("▧", "Screenshot",
            "Mengambil screenshot tanpa tombol Support Touch", () -> {
                if (!FloatingService.requestCleanScreenshot()) {
                    runAccessibilityAction(
                        TouchAccessibilityService.ACTION_SCREENSHOT
                    );
                }
            });

        space(15);
    }

    void createDeviceControls() {
        heading("Device Controls");

        addAction("♪", "Volume Up",
            "Menaikkan volume media", () -> {
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI
                );
            });

        addAction("♫", "Volume Down",
            "Menurunkan volume media", () -> {
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                );
            });

        addAction("☀", "Brightness",
            "Buka pengaturan kecerahan", () -> {
                startActivity(new Intent(
                    Settings.ACTION_DISPLAY_SETTINGS
                ));
            });

        space(15);
    }

    void createThemeSection() {
        heading("Personalization");

        addAction("◉", "Custom Settings",
            "Atur ukuran, warna, transparansi, dan tema", () -> {
                showCustomizationMenu();
            });
    }

    void showCustomizationMenu() {
        String[] options = {
            "Ukuran tombol Assistive Touch",
            "Transparansi tombol Assistive Touch",
            "Warna tombol Assistive Touch",
            "Tema panel"
        };

        new AlertDialog.Builder(this)
            .setTitle("Support Touch Settings")
            .setItems(options, (dialog, which) -> {
                if (which == 0) chooseButtonSize();
                else if (which == 1) chooseButtonOpacity();
                else if (which == 2) chooseButtonColor();
                else choosePanelTheme();
            })
            .setNegativeButton("Tutup", null)
            .show();
    }

    void chooseButtonSize() {
        String[] labels = {"Kecil", "Sedang", "Besar"};
        int[] values = {48, 58, 68};

        new AlertDialog.Builder(this)
            .setTitle("Ukuran tombol Assistive Touch")
            .setItems(labels, (dialog, which) -> {
                saveSetting("button_size", values[which]);
                settingSaved();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    void chooseButtonOpacity() {
        String[] labels = {"25%", "50%", "75%", "100%"};
        int[] values = {64, 128, 191, 255};

        new AlertDialog.Builder(this)
            .setTitle("Transparansi tombol Assistive Touch")
            .setItems(labels, (dialog, which) -> {
                saveSetting("button_alpha", values[which]);
                settingSaved();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    void chooseButtonColor() {
        String[] labels = {"Biru", "Ungu", "Merah", "Hijau"};
        int[] values = {
            Color.rgb(45, 112, 240),
            Color.rgb(139, 92, 246),
            Color.rgb(230, 70, 80),
            Color.rgb(30, 170, 120)
        };

        new AlertDialog.Builder(this)
            .setTitle("Warna tombol Assistive Touch")
            .setItems(labels, (dialog, which) -> {
                saveSetting("button_color", values[which]);
                settingSaved();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    void choosePanelTheme() {
        String[] labels = {"Dark", "Light"};
        int[] values = {0, 1};

        new AlertDialog.Builder(this)
            .setTitle("Tema panel")
            .setItems(labels, (dialog, which) -> {
                saveSetting("panel_theme", values[which]);
                settingSaved();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    void saveSetting(String key, int value) {
        getSharedPreferences("support_touch_settings", MODE_PRIVATE)
            .edit()
            .putInt(key, value)
            .apply();
    }

    void settingSaved() {
        Toast.makeText(
            this,
            "Pengaturan disimpan. Aktifkan ulang Floating Touch agar perubahan diterapkan.",
            Toast.LENGTH_LONG
        ).show();
    }

    void runAccessibilityAction(String action) {
        if (TouchAccessibilityService.performAction(action)) {
            return;
        }

        Toast.makeText(
            this,
            "Aktifkan Support Touch di pengaturan Accessibility terlebih dahulu",
            Toast.LENGTH_LONG
        ).show();

        startActivity(new Intent(
            Settings.ACTION_ACCESSIBILITY_SETTINGS
        ));
    }

    void heading(String name) {
        main.addView(text(
            name, 20, dark, true
        ));

        space(10);
    }

    void addAction(
        String symbol,
        String name,
        String description,
        Runnable action
    ) {
        LinearLayout row = new LinearLayout(this);

        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(14, 12, 14, 12);
        row.setBackground(background(Color.WHITE, 17));

        TextView icon = text(
            symbol, 27, blue, true
        );

        icon.setGravity(Gravity.CENTER);

        row.addView(icon,
            new LinearLayout.LayoutParams(55, 55)
        );

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(12, 0, 0, 0);

        info.addView(text(name, 16, dark, true));
        info.addView(text(description, 12, gray, false));

        row.addView(info,
            new LinearLayout.LayoutParams(0, -2, 1)
        );

        row.setOnClickListener(v -> action.run());

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, -2);

        params.bottomMargin = 10;

        main.addView(row, params);
    }

    LinearLayout card() {
        LinearLayout box = new LinearLayout(this);

        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 20, 20, 20);
        box.setBackground(background(Color.WHITE, 22));

        return box;
    }

    TextView button(String name) {
        TextView b = new TextView(this);

        b.setText(name);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(12, 16, 12, 16);
        b.setBackground(background(blue, 14));

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(-1, -2);

        params.topMargin = 14;
        b.setLayoutParams(params);

        return b;
    }

    TextView text(
        String value,
        int size,
        int color,
        boolean bold
    ) {
        TextView t = new TextView(this);

        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, 5, 0, 5);

        if (bold) {
            t.setTypeface(null, Typeface.BOLD);
        }

        return t;
    }

    GradientDrawable background(
        int color,
        int radius
    ) {
        GradientDrawable bg = new GradientDrawable();

        bg.setColor(color);
        bg.setCornerRadius(
            radius * getResources()
                .getDisplayMetrics().density
        );

        return bg;
    }

    void space(int height) {
        View v = new View(this);

        main.addView(v,
            new LinearLayout.LayoutParams(1, height)
        );
    }
    
    private void requestNotificationPermission() {

    if (Build.VERSION.SDK_INT >= 33) {

        if (checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                new String[]{
                    Manifest.permission.POST_NOTIFICATIONS
                },
                100
            );
        }
    }
  }
}