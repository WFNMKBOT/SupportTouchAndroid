package com.supporttouch.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.ServiceInfo;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {

private static final String CHANNEL_ID = "support_touch_channel";
private static final int NOTIFICATION_ID = 1001;

private void startForegroundNotification() {

    Notification notification;

    if (Build.VERSION.SDK_INT >= 26) {

        NotificationChannel channel =
            new NotificationChannel(
                CHANNEL_ID,
                "Support Touch",
                NotificationManager.IMPORTANCE_LOW
            );

        NotificationManager manager =
            getSystemService(NotificationManager.class);

        manager.createNotificationChannel(channel);

        notification =
            new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();

    } else {

        notification =
            new Notification.Builder(this)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
    }

    if (Build.VERSION.SDK_INT >= 34) {

        startForeground(
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        );

    } else {

        startForeground(
            NOTIFICATION_ID,
            notification
        );
    }
}

    WindowManager wm;
    TextView floatingButton;
    LinearLayout panel;

    WindowManager.LayoutParams buttonParams;
    WindowManager.LayoutParams panelParams;

    AudioManager audio;

    int blue = Color.rgb(45, 112, 240);
    int dark = Color.rgb(22, 32, 51);

    float startX, startY;
    int originalX, originalY;
    boolean moved;

    @Override
public void onCreate() {
    super.onCreate();

    startForegroundNotification();

    wm = (WindowManager)
        getSystemService(WINDOW_SERVICE);

    audio = (AudioManager)
        getSystemService(AUDIO_SERVICE);

    showFloatingButton();
    createPanel();
}

    private int dp(int value) {
        return (int) (value *
            getResources().getDisplayMetrics().density);
    }

    private int overlayType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams
                .TYPE_APPLICATION_OVERLAY;
        }

        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(
        int color, int radius
    ) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }

    private void showFloatingButton() {

        floatingButton = new TextView(this);

        floatingButton.setText("S");
        floatingButton.setTextSize(23);
        floatingButton.setTextColor(Color.WHITE);
        floatingButton.setGravity(Gravity.CENTER);
        floatingButton.setElevation(dp(8));
        floatingButton.setBackground(
            shape(blue, 40)
        );

        buttonParams = new WindowManager.LayoutParams(
            dp(58),
            dp(58),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        buttonParams.gravity =
            Gravity.TOP | Gravity.START;

        buttonParams.x = dp(20);
        buttonParams.y = dp(300);

        floatingButton.setOnTouchListener(
            (view, event) -> {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        startX = event.getRawX();
                        startY = event.getRawY();

                        originalX = buttonParams.x;
                        originalY = buttonParams.y;

                        moved = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:

                        float dx =
                            event.getRawX() - startX;

                        float dy =
                            event.getRawY() - startY;

                        if (Math.abs(dx) > dp(5) ||
                            Math.abs(dy) > dp(5)) {
                            moved = true;
                        }

                        if (moved) {
                            buttonParams.x =
                                originalX + (int) dx;

                            buttonParams.y =
                                originalY + (int) dy;

                            wm.updateViewLayout(
                                floatingButton,
                                buttonParams
                            );
                        }

                        return true;

                    case MotionEvent.ACTION_UP:

                        if (!moved) {
                            togglePanel();
                        }

                        return true;
                }

                return false;
            }
        );

        wm.addView(
            floatingButton,
            buttonParams
        );
    }

    private void createPanel() {

        panel = new LinearLayout(this);
        panel.setOrientation(
            LinearLayout.VERTICAL
        );

        panel.setPadding(
            dp(16), dp(16), dp(16), dp(16)
        );

        panel.setBackground(
            shape(Color.WHITE, 22)
        );

        panel.setElevation(dp(12));

        TextView title = new TextView(this);
        title.setText("SUPPORT TOUCH");
        title.setTextSize(17);
        title.setTextColor(dark);
        title.setTypeface(null, 1);

        panel.addView(title);
        addSpace(10);

        addControl("⌂", "HOME", () ->
            runAction(
                TouchAccessibilityService.ACTION_HOME
            )
        );

        addControl("‹", "BACK", () ->
            runAction(
                TouchAccessibilityService.ACTION_BACK
            )
        );

        addControl("▣", "RECENT APPS", () ->
            runAction(
                TouchAccessibilityService.ACTION_RECENTS
            )
        );

        addControl("▧", "SCREENSHOT", () ->
            runAction(
                TouchAccessibilityService.ACTION_SCREENSHOT
            )
        );

        addControl("＋", "VOLUME UP", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addControl("－", "VOLUME DOWN", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addControl("☀", "BRIGHTNESS", () -> {
            Intent intent = new Intent(
                Settings.ACTION_DISPLAY_SETTINGS
            );

            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
            );

            startActivity(intent);
        });

        TextView close = new TextView(this);
        close.setText("TUTUP PANEL");
        close.setTextColor(Color.WHITE);
        close.setTextSize(13);
        close.setTypeface(null, 1);
        close.setGravity(Gravity.CENTER);
        close.setPadding(12, 14, 12, 14);
        close.setBackground(shape(blue, 14));

        close.setOnClickListener(v ->
            panel.setVisibility(View.GONE)
        );

        panel.addView(close);

        panelParams = new WindowManager.LayoutParams(
            dp(230),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        panelParams.gravity =
            Gravity.TOP | Gravity.START;

        panelParams.x = dp(20);
        panelParams.y = dp(370);

        panel.setVisibility(View.GONE);

        wm.addView(panel, panelParams);
    }

    private void addControl(
        String icon,
        String name,
        Runnable action
    ) {
        LinearLayout row = new LinearLayout(this);

        row.setOrientation(
            LinearLayout.HORIZONTAL
        );

        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(10), dp(8), dp(10));
        row.setBackground(shape(
            Color.rgb(244, 247, 252), 12
        ));

        TextView symbol = new TextView(this);
        symbol.setText(icon);
        symbol.setTextSize(21);
        symbol.setTextColor(blue);
        symbol.setGravity(Gravity.CENTER);

        row.addView(symbol,
            new LinearLayout.LayoutParams(
                dp(40), dp(35)
            )
        );

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(13);
        label.setTextColor(dark);
        label.setTypeface(null, 1);
        label.setPadding(dp(10), 0, 0, 0);

        row.addView(label);

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(
                -1, -2
            );

        params.bottomMargin = dp(7);

        panel.addView(row, params);

        row.setOnClickListener(v -> action.run());
    }

    private void addSpace(int height) {
        View space = new View(this);

        panel.addView(space,
            new LinearLayout.LayoutParams(
                1, dp(height)
            )
        );
    }

    private void togglePanel() {
        if (panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.GONE);
        } else {
            panel.setVisibility(View.VISIBLE);
        }
    }

    private void runAction(String action) {

        if (!TouchAccessibilityService.performAction(action)) {

            Toast.makeText(
                this,
                "Aktifkan Accessibility Support Touch dahulu",
                Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (floatingButton != null) {
            wm.removeView(floatingButton);
            floatingButton = null;
        }

        if (panel != null) {
            wm.removeView(panel);
            panel = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}