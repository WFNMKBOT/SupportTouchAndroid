package com.supporttouch.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.ServiceInfo;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {

private static final String CHANNEL_ID = "support_touch_channel";
private static final int NOTIFICATION_ID = 1001;

private void startForegroundNotification() {

    Notification notification;

    if (Build.VERSION.SDK_INT >= 26) {

        NotificationChannel channel =
            new NotificationChannel(
                CHANNEL_ID,
                "Support Touch",
                NotificationManager.IMPORTANCE_LOW
            );

        NotificationManager manager =
            getSystemService(NotificationManager.class);

        manager.createNotificationChannel(channel);

        notification =
            new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();

    } else {

        notification =
            new Notification.Builder(this)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
    }

    if (Build.VERSION.SDK_INT >= 34) {

        startForeground(
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        );

    } else {

        startForeground(
            NOTIFICATION_ID,
            notification
        );
    }
}

    WindowManager wm;
    TextView floatingButton;
    LinearLayout panel;

    WindowManager.LayoutParams buttonParams;
    WindowManager.LayoutParams panelParams;

    AudioManager audio;

    int blue = Color.rgb(45, 112, 240);
    int dark = Color.rgb(22, 32, 51);

    float startX, startY;
    int originalX, originalY;
    boolean moved;

    @Override
public void onCreate() {
    super.onCreate();

    startForegroundNotification();

    wm = (WindowManager)
        getSystemService(WINDOW_SERVICE);

    audio = (AudioManager)
        getSystemService(AUDIO_SERVICE);

    showFloatingButton();
    createPanel();
}

    private int dp(int value) {
        return (int) (value *
            getResources().getDisplayMetrics().density);
    }

    private int overlayType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams
                .TYPE_APPLICATION_OVERLAY;
        }

        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(
        int color, int radius
    ) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }

    private void showFloatingButton() {

        floatingButton = new TextView(this);

        // Tombol bulat bergaya Assistive Touch
floatingButton.setText("⦿");
floatingButton.setTextSize(31);
floatingButton.setTextColor(Color.WHITE);
floatingButton.setGravity(Gravity.CENTER);
floatingButton.setElevation(dp(8));
floatingButton.setBackground(
    shape(blue, 100)
);

        buttonParams = new WindowManager.LayoutParams(
            dp(58),
            dp(58),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        buttonParams.gravity =
            Gravity.TOP | Gravity.START;

        buttonParams.x = dp(20);
        buttonParams.y = dp(300);

        floatingButton.setOnTouchListener(
            (view, event) -> {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        startX = event.getRawX();
                        startY = event.getRawY();

                        originalX = buttonParams.x;
                        originalY = buttonParams.y;

                        moved = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:

                        float dx =
                            event.getRawX() - startX;

                        float dy =
                            event.getRawY() - startY;

                        if (Math.abs(dx) > dp(5) ||
                            Math.abs(dy) > dp(5)) {
                            moved = true;
                        }

                        if (moved) {
                            buttonParams.x =
                                originalX + (int) dx;

                            buttonParams.y =
                                originalY + (int) dy;

                            wm.updateViewLayout(
                                floatingButton,
                                buttonParams
                            );
                        }

                        return true;

                    case MotionEvent.ACTION_UP:

                        if (!moved) {
                            togglePanel();
                        }

                        return true;
                }

                return false;
            }
        );

        wm.addView(
            floatingButton,
            buttonParams
        );
    }

    private void createPanel() {

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));

        GradientDrawable panelBg = shape(
            Color.rgb(17, 25, 40), 24
        );
        panelBg.setStroke(dp(1), Color.rgb(55, 82, 125));
        panel.setBackground(panelBg);
        panel.setElevation(dp(18));

        TextView title = new TextView(this);
        title.setText("SUPPORT TOUCH");
        title.setTextSize(17);
        title.setTextColor(Color.WHITE);
        title.setTypeface(null, 1);
        title.setLetterSpacing(0.06f);
        panel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("QUICK CONTROL");
        subtitle.setTextSize(10);
        subtitle.setTextColor(Color.rgb(145, 166, 200));
        subtitle.setPadding(0, dp(3), 0, dp(12));
        panel.addView(subtitle);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setRowCount(4);

        addControl(grid, "⌂", "HOME", () ->
            runAction(TouchAccessibilityService.ACTION_HOME)
        );

        addControl(grid, "‹", "BACK", () ->
            runAction(TouchAccessibilityService.ACTION_BACK)
        );

        addControl(grid, "▣", "RECENTS", () ->
            runAction(TouchAccessibilityService.ACTION_RECENTS)
        );

        addControl(grid, "▧", "SCREENSHOT", () ->
            runAction(TouchAccessibilityService.ACTION_SCREENSHOT)
        );

        addControl(grid, "＋", "VOLUME UP", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addControl(grid, "－", "VOLUME DOWN", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addControl(grid, "☀", "BRIGHTNESS", () -> {
            Intent intent = new Intent(
                Settings.ACTION_DISPLAY_SETTINGS
            );
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        addControl(grid, "⚙", "SETTINGS", () -> {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        panel.addView(grid);

        TextView close = new TextView(this);
        close.setText("CLOSE PANEL");
        close.setTextColor(Color.WHITE);
        close.setTextSize(12);
        close.setTypeface(null, 1);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(12), dp(12), dp(12), dp(12));
        close.setBackground(shape(blue, 16));

        LinearLayout.LayoutParams closeParams =
            new LinearLayout.LayoutParams(-1, -2);
        closeParams.topMargin = dp(10);
        panel.addView(close, closeParams);

        close.setOnClickListener(v ->
            panel.setVisibility(View.GONE)
        );

        panelParams = new WindowManager.LayoutParams(
            dp(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(20);
        panelParams.y = dp(250);

        panel.setVisibility(View.GONE);
        wm.addView(panel, panelParams);
    }

    private void addControl(
        GridLayout grid,
        String icon,
        String name,
        Runnable action
    ) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(5), dp(8), dp(5), dp(8));

        GradientDrawable itemBg = shape(
            Color.rgb(29, 43, 65), 16
        );
        itemBg.setStroke(dp(1), Color.rgb(48, 70, 105));
        item.setBackground(itemBg);

        TextView symbol = new TextView(this);
        symbol.setText(icon);
        symbol.setTextSize(23);
        symbol.setTextColor(Color.rgb(91, 151, 255));
        symbol.setGravity(Gravity.CENTER);

        item.addView(symbol);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(10);
        label.setTextColor(Color.WHITE);
        label.setTypeface(null, 1);
        label.setGravity(Gravity.CENTER);
        label.setPadding(0, dp(4), 0, 0);

        item.addView(label);

        GridLayout.LayoutParams params =
            new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            );

        params.width = 0;
        params.height = dp(72);
        params.setMargins(dp(4), dp(4), dp(4), dp(4));

        grid.addView(item, params);
        item.setOnClickListener(v -> action.run());
    }

    private void addSpace(int height) {
        View space = new View(this);

        panel.addView(space,
            new LinearLayout.LayoutParams(
                1, dp(height)
            )
        );
    }

    private void togglePanel() {
        if (panel.getVisibility() == View.VISIBLE) {
            panel.setVisibility(View.GONE);
        } else {
            panel.setVisibility(View.VISIBLE);
        }
    }

    private void runAction(String action) {

        if (!TouchAccessibilityService.performAction(action)) {

            Toast.makeText(
                this,
                "Aktifkan Accessibility Support Touch dahulu",
                Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (floatingButton != null) {
            wm.removeView(floatingButton);
            floatingButton = null;
        }

        if (panel != null) {
            wm.removeView(panel);
            panel = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}