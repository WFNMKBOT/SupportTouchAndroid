package com.supporttouch.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.ServiceInfo;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {

private static volatile FloatingService instance;
private boolean screenshotInProgress = false;

public static boolean requestCleanScreenshot() {
    FloatingService service = instance;
    if (service == null) {
        return false;
    }
    service.beginCleanScreenshot();
    return true;
}

private static final String CHANNEL_ID = "support_touch_channel";
private static final int NOTIFICATION_ID = 1001;

private void startForegroundNotification() {

    Notification notification;

    if (Build.VERSION.SDK_INT >= 26) {

        NotificationChannel channel =
            new NotificationChannel(
                CHANNEL_ID,
                "Support Touch",
                NotificationManager.IMPORTANCE_LOW
            );

        NotificationManager manager =
            getSystemService(NotificationManager.class);

        manager.createNotificationChannel(channel);

        notification =
            new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();

    } else {

        notification =
            new Notification.Builder(this)
                .setContentTitle("Support Touch aktif")
                .setContentText("Tombol kontrol melayang sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
    }

    if (Build.VERSION.SDK_INT >= 34) {

        startForeground(
            NOTIFICATION_ID,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        );

    } else {

        startForeground(
            NOTIFICATION_ID,
            notification
        );
    }
}

    WindowManager wm;
    TextView floatingButton;
    LinearLayout panel;

    WindowManager.LayoutParams buttonParams;
    WindowManager.LayoutParams panelParams;

    AudioManager audio;
    SharedPreferences preferences;

    int buttonSize = 58;
    int buttonAlpha = 255;
    int buttonColor = Color.rgb(45, 112, 240);
    boolean lightPanel = false;

    private final Handler panelHandler = new Handler(Looper.getMainLooper());
    private Runnable hidePanelRunnable;

    int blue = Color.rgb(45, 112, 240);
    int dark = Color.rgb(22, 32, 51);

    float startX, startY;
    int originalX, originalY;
    boolean moved;

    @Override
public void onCreate() {
    super.onCreate();
    instance = this;

    startForegroundNotification();

    wm = (WindowManager)
        getSystemService(WINDOW_SERVICE);

    audio = (AudioManager)
        getSystemService(AUDIO_SERVICE);

    preferences = getSharedPreferences(
        "support_touch_settings", MODE_PRIVATE
    );

    buttonSize = preferences.getInt("button_size", 58);
    buttonAlpha = preferences.getInt("button_alpha", 255);
    buttonColor = preferences.getInt(
        "button_color", Color.rgb(45, 112, 240)
    );
    lightPanel = preferences.getInt("panel_theme", 0) == 1;

    showFloatingButton();
    createPanel();
}

    private int dp(int value) {
        return (int) (value *
            getResources().getDisplayMetrics().density);
    }

    private int overlayType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return WindowManager.LayoutParams
                .TYPE_APPLICATION_OVERLAY;
        }

        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private GradientDrawable shape(
        int color, int radius
    ) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radius));
        return bg;
    }

    private void showFloatingButton() {

        floatingButton = new TextView(this);

        floatingButton.setText("⦿");
        floatingButton.setTextSize(21);
        floatingButton.setTextColor(Color.WHITE);
        floatingButton.setGravity(Gravity.CENTER);
        floatingButton.setElevation(dp(8));

        floatingButton.setBackground(
            shape(buttonColor, 100)
        );
        floatingButton.setAlpha(buttonAlpha / 255f);

        buttonParams = new WindowManager.LayoutParams(
            dp(buttonSize),
            dp(buttonSize),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        buttonParams.gravity =
            Gravity.TOP | Gravity.START;

        buttonParams.x = dp(20);
        buttonParams.y = dp(300);

        floatingButton.setOnTouchListener(
            (view, event) -> {

                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        startX = event.getRawX();
                        startY = event.getRawY();

                        originalX = buttonParams.x;
                        originalY = buttonParams.y;

                        moved = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:

                        float dx =
                            event.getRawX() - startX;

                        float dy =
                            event.getRawY() - startY;

                        if (Math.abs(dx) > dp(5) ||
                            Math.abs(dy) > dp(5)) {
                            moved = true;
                        }

                        if (moved) {
                            buttonParams.x =
                                originalX + (int) dx;

                            buttonParams.y =
                                originalY + (int) dy;

                            wm.updateViewLayout(
                                floatingButton,
                                buttonParams
                            );
                        }

                        return true;

                    case MotionEvent.ACTION_UP:

                        if (!moved) {
                            togglePanel();
                        }

                        return true;
                }

                return false;
            }
        );

        wm.addView(
            floatingButton,
            buttonParams
        );
    }

    private void createPanel() {

        // Toolbar horizontal yang muncul tepat di samping tombol melayang.
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(7), dp(6), dp(7), dp(6));

        int panelColor = lightPanel
            ? Color.rgb(245, 248, 253)
            : Color.rgb(17, 25, 40);
        int panelBorder = lightPanel
            ? Color.rgb(205, 215, 230)
            : Color.rgb(55, 82, 125);

        GradientDrawable panelBg = shape(panelColor, 28);
        panelBg.setStroke(dp(1), panelBorder);
        panel.setBackground(panelBg);
        panel.setElevation(dp(18));

        android.widget.HorizontalScrollView scroll =
            new android.widget.HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);

        addToolbarControl(toolbar, "⌂", "Home", () ->
            runAction(TouchAccessibilityService.ACTION_HOME)
        );

        addToolbarControl(toolbar, "‹", "Back", () ->
            runAction(TouchAccessibilityService.ACTION_BACK)
        );

        addToolbarControl(toolbar, "▣", "Recent", () ->
            runAction(TouchAccessibilityService.ACTION_RECENTS)
        );

        addToolbarControl(toolbar, "▧", "Shot", () ->
            beginCleanScreenshot()
        );

        addToolbarControl(toolbar, "＋", "Vol+", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_RAISE,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addToolbarControl(toolbar, "－", "Vol−", () ->
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        );

        addToolbarControl(toolbar, "☀", "Bright", () -> {
            Intent intent = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        addToolbarControl(toolbar, "⚙", "Settings", () -> {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        scroll.addView(toolbar);
        panel.addView(scroll, new LinearLayout.LayoutParams(
            dp(270), dp(56)
        ));

        panelParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );

        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(84);
        panelParams.y = dp(300);
        panel.setVisibility(View.GONE);

        wm.addView(panel, panelParams);
    }

    private void addToolbarControl(
        LinearLayout toolbar,
        String icon,
        String name,
        Runnable action
    ) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(3), dp(4), dp(3), dp(4));

        int itemColor = lightPanel
            ? Color.rgb(230, 237, 247)
            : Color.rgb(29, 43, 65);
        int itemBorder = lightPanel
            ? Color.rgb(205, 215, 230)
            : Color.rgb(48, 70, 105);
        int labelColor = lightPanel
            ? Color.rgb(35, 48, 68)
            : Color.WHITE;

        GradientDrawable itemBg = shape(itemColor, 14);
        itemBg.setStroke(dp(1), itemBorder);
        item.setBackground(itemBg);

        TextView symbol = new TextView(this);
        symbol.setText(icon);
        symbol.setTextSize(14);
        symbol.setTextColor(Color.rgb(91, 151, 255));
        symbol.setGravity(Gravity.CENTER);
        item.addView(symbol);

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(7);
        label.setTextColor(labelColor);
        label.setGravity(Gravity.CENTER);
        label.setTypeface(null, 1);
        item.addView(label);

        LinearLayout.LayoutParams params =
            new LinearLayout.LayoutParams(dp(40), dp(46));
        params.setMargins(dp(3), 0, dp(3), 0);

        toolbar.addView(item, params);
        item.setOnClickListener(v -> {
            action.run();
            hidePanelAnimated();
        });
    }

    private void addSpace(int height) {
        View space = new View(this);

        panel.addView(space,
            new LinearLayout.LayoutParams(
                1, dp(height)
            )
        );
    }

    private void togglePanel() {
        if (panel.getVisibility() == View.VISIBLE) {
            hidePanelAnimated();
            return;
        }

        // Ukuran layar dipakai agar toolbar muncul di sisi yang masih memiliki ruang.
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int toolbarWidth = dp(284);
        int gap = dp(8);

        int rightSpace = screenWidth -
            (buttonParams.x + dp(buttonSize));

        if (rightSpace >= toolbarWidth + gap) {
            panelParams.x = buttonParams.x + dp(buttonSize) + gap;
        } else {
            panelParams.x = Math.max(
                dp(4),
                buttonParams.x - toolbarWidth - gap
            );
        }

        panelParams.y = Math.max(dp(28), buttonParams.y + dp(2));

        wm.updateViewLayout(panel, panelParams);

        if (hidePanelRunnable != null) {
            panelHandler.removeCallbacks(hidePanelRunnable);
        }

        panel.setAlpha(0f);
        panel.setTranslationX(dp(12));
        panel.setVisibility(View.VISIBLE);
        panel.animate()
            .alpha(1f)
            .translationX(0f)
            .setDuration(180)
            .start();

        // Tutup otomatis setelah 5 detik jika tidak ada tindakan.
        hidePanelRunnable = () -> hidePanelAnimated();
        panelHandler.postDelayed(hidePanelRunnable, 5000);
    }

    private void hidePanelAnimated() {
        if (panel == null || panel.getVisibility() != View.VISIBLE) {
            return;
        }

        if (hidePanelRunnable != null) {
            panelHandler.removeCallbacks(hidePanelRunnable);
            hidePanelRunnable = null;
        }

        panel.animate()
            .alpha(0f)
            .translationX(dp(12))
            .setDuration(150)
            .withEndAction(() -> {
                if (panel != null) {
                    panel.setVisibility(View.GONE);
                    panel.setAlpha(1f);
                    panel.setTranslationX(0f);
                }
            })
            .start();
    }

    /**
     * Hide Support Touch overlays briefly before requesting Android's
     * accessibility screenshot action, then restore the floating button.
     */
    private void beginCleanScreenshot() {
        if (screenshotInProgress) {
            return;
        }

        if (Build.VERSION.SDK_INT < 28) {
            Toast.makeText(
                this,
                "Screenshot melalui Accessibility memerlukan Android 9 atau lebih baru",
                Toast.LENGTH_LONG
            ).show();
            return;
        }

        if (hidePanelRunnable != null) {
            panelHandler.removeCallbacks(hidePanelRunnable);
            hidePanelRunnable = null;
        }

        screenshotInProgress = true;

        if (panel != null) {
            panel.animate().cancel();
            panel.setVisibility(View.GONE);
        }

        if (floatingButton != null) {
            floatingButton.setVisibility(View.INVISIBLE);
        }

        // Wait briefly so WindowManager removes the overlays from the captured frame.
        panelHandler.postDelayed(() -> {
            boolean accepted = TouchAccessibilityService.performAction(
                TouchAccessibilityService.ACTION_SCREENSHOT
            );

            if (!accepted) {
                Toast.makeText(
                    this,
                    "Aktifkan izin Accessibility Support Touch terlebih dahulu",
                    Toast.LENGTH_LONG
                ).show();
            }

            // Restore the floating button after Android has time to capture.
            panelHandler.postDelayed(() -> {
                if (floatingButton != null) {
                    floatingButton.setVisibility(View.VISIBLE);
                }
                screenshotInProgress = false;
            }, 900);

        }, 300);
    }

    private void runAction(String action) {

        if (!TouchAccessibilityService.performAction(action)) {

            Toast.makeText(
                this,
                "Aktifkan Accessibility Support Touch dahulu",
                Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    public void onDestroy() {
        if (hidePanelRunnable != null) {
            panelHandler.removeCallbacks(hidePanelRunnable);
            hidePanelRunnable = null;
        }
        panelHandler.removeCallbacksAndMessages(null);

        super.onDestroy();

        if (instance == this) {
            instance = null;
        }

        if (floatingButton != null) {
            try {
                wm.removeView(floatingButton);
            } catch (IllegalArgumentException ignored) {
                // View was already detached.
            }
            floatingButton = null;
        }

        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (IllegalArgumentException ignored) {
                // View was already detached.
            }
            panel = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}