package com.supporttouch.android;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class TouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_HOME = "HOME";
    public static final String ACTION_BACK = "BACK";
    public static final String ACTION_RECENTS = "RECENTS";
    public static final String ACTION_SCREENSHOT = "SCREENSHOT";

    private static volatile TouchAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        instance = this;

        Toast.makeText(
            this,
            "Support Touch siap digunakan",
            Toast.LENGTH_SHORT
        ).show();
    }

    public static boolean performAction(String action) {
        TouchAccessibilityService service = instance;

        if (service == null || action == null) {
            return false;
        }

        switch (action) {
            case ACTION_HOME:
                return service.performGlobalAction(GLOBAL_ACTION_HOME);

            case ACTION_BACK:
                return service.performGlobalAction(GLOBAL_ACTION_BACK);

            case ACTION_RECENTS:
                return service.performGlobalAction(GLOBAL_ACTION_RECENTS);

            case ACTION_SCREENSHOT:
                if (Build.VERSION.SDK_INT >= 28) {
                    return service.performGlobalAction(
                        GLOBAL_ACTION_TAKE_SCREENSHOT
                    );
                }
                return false;

            default:
                return false;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Aplikasi tidak membaca atau menyimpan isi layar pengguna.
    }

    @Override
    public void onInterrupt() {
        // Tidak ada proses berkelanjutan yang perlu dihentikan.
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (instance == this) {
            instance = null;
        }
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }
}