package com.supporttouch.android;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.os.Build;
import android.widget.Toast;

public class TouchAccessibilityService
        extends AccessibilityService {

    public static final String ACTION_HOME = "HOME";
    public static final String ACTION_BACK = "BACK";
    public static final String ACTION_RECENTS = "RECENTS";
    public static final String ACTION_SCREENSHOT = "SCREENSHOT";

    private static TouchAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        instance = this;

        Toast.makeText(
            this,
            "Support Touch siap digunakan",
            Toast.LENGTH_SHORT
        ).show();
    }

    public static boolean performAction(String action) {

        if (instance == null) {
            return false;
        }

        switch (action) {

            case ACTION_HOME:
                return instance.performGlobalAction(
                    GLOBAL_ACTION_HOME
                );

            case ACTION_BACK:
                return instance.performGlobalAction(
                    GLOBAL_ACTION_BACK
                );

            case ACTION_RECENTS:
                return instance.performGlobalAction(
                    GLOBAL_ACTION_RECENTS
                );

            case ACTION_SCREENSHOT:

                if (Build.VERSION.SDK_INT >= 28) {
                    return instance.performGlobalAction(
                        GLOBAL_ACTION_TAKE_SCREENSHOT
                    );
                }

                return false;
        }

        return false;
    }

    @Override
    public void onAccessibilityEvent(
        AccessibilityEvent event
    ) {
        // Tidak mengambil isi layar pengguna.
    }

    @Override
    public void onInterrupt() {
        if (instance == this) {
            instance = null;
        }
    }

    @Override
    public void onDestroy() {
        if (instance == this) {
            instance = null;
        }

        super.onDestroy();
    }

}